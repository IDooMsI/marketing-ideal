
<?php $__env->startSection('content'); ?>
    <section class="container">
        <div class="text-center mb-3">
            <h1 id="title-service">SERVICIOS PARA CADA TIPO DE CLIENTE</h1>
        </div>
        <div class="border-top border-warning mt-3"></div>
        <div class="border-top border-warning w-75 mx-auto my-2"></div>
        <div class="border-top border-warning w-50 mx-auto mb-3"></div>
        <div class="row">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-md-6 col-lg-4">
                <div class="col-12">
                    <img class="w-100" src="<?php echo e(asset('storage/'.$service->image)); ?>" alt="">
                </div>
                <div class="col-12">
                    <?php switch($service->name):
                        case ('starting'): ?>
                            <div class="col-12 text-center my-3">
                                <button onclick="whatsapp('starting')" class="btn btn-block btn-outline-secondary">Contratar</button>
                            </div>
                             <ul class="border border-warning rounded text-white" style="background-color:black">
                                <?php $__currentLoopData = $service->specs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="my-3" style="list-style:circle "><?php echo e($spec->description); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php break; ?>
                        <?php case ('advanced'): ?>
                            <div class="col-12 text-center my-3">
                                <button onclick="whatsapp('advanced')" class="btn btn-block btn-outline-success">Contratar</button>
                            </div>
                            <ul class="border border-warning rounded text-success" style="background-color:black">
                                <?php $__currentLoopData = $service->specs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="my-3" style="list-style:circle "><?php echo e($spec->description); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php break; ?>
                        <?php case ('expert'): ?>
                            <div class="col-12 text-center my-3">
                                <button onclick="whatsapp('expert')" class="btn btn-block btn-outline-warning">Contratar</button>
                            </div>
                             <ul class="border border-warning rounded text-warning" style="background-color:black">
                                <?php $__currentLoopData = $service->specs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="my-3" style="list-style:circle "><?php echo e($spec->description); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php break; ?>
                    <?php endswitch; ?>
                </div>
                <div class="col-12 text-center">
                    <h3>$ <?php echo e($service->price); ?></h3>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DooM\Desktop\proyectos\marketing-ideal\resources\views/service.blade.php ENDPATH**/ ?>