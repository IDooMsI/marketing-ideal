
<?php $__env->startSection('content'); ?>
<div class="col-12">
    <div class="col-12 text-center mb-5">
        <h2>Editar Subcategoria</h2>
    </div>
    <form class="col-12 mx-auto" action="<?php echo e(route('subcategory.update' ,['subcategory'=>$subcategory])); ?>" method="post" enctype="multipart/form-data">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-row">
            <div class="form-group col-4 mx-auto">
                <h4><label for="">Nombre</label></h4>
                <input name="name" class="form-control" type="text" value="<?php echo e($subcategory->name); ?>">
                <small id="passwordHelpBlock" class="form-text text-muted"><b>Nuevo nombre de la subcategoria</b></small>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="error" class="alert alert-danger mx-auto col-11 col-sm-4 col-lg-12"><span><?php echo e($message); ?></span></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div id="buttons" class="text-center col-12">
            <button class="mx-2 btn btn-outline-dark" type="submit">Agregar</button>
            <a href="<?php echo e(route('subcategory.index')); ?>"><button class="btn btn-outline-dark" type="button">Cancelar</button></a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DooM\Desktop\proyectos\marketing-ideal\resources\views/admin/subcategory/edit.blade.php ENDPATH**/ ?>