
<?php $__env->startSection('content'); ?>
<div class="col-12">
    <div class="col-12 text-center mb-5">
        <h2>Editar Servicio</h2>
    </div>
    <form class="col-12 mx-auto" action="<?php echo e(route('service.update' ,['service'=>$service])); ?>" method="post" enctype="multipart/form-data">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-row">
            <div class="form-group col-12 col-md-6 col-lg-4">
                <h4><label for="">Nombre</label></h4>
                <input name="name" class="form-control" type="text" value="<?php echo e($service->name); ?>">
                <small id="passwordHelpBlock" class="form-text text-muted"><b>Nombre del servicio</b></small>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="error" class="alert alert-danger mx-auto col-11 col-sm-4 col-lg-12"><span><?php echo e($message); ?></span></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-12 col-md-6 col-lg-4">
                <h4><label for="">Precio</label></h4>
                <input name="price" class="form-control" type="number" value="<?php echo e($service->price); ?>">
                <small id="passwordHelpBlock" class="form-text text-muted"><b>Precio del servicio</b></small>
                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="error" class="alert alert-danger mx-auto col-11 col-sm-4 col-lg-12"><span><?php echo e($message); ?></span></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-12 col-md-6 col-lg-4">
                <h4><label for="">Imagen</label></h4>
                <input name="image" class="form-control-file" type="file">
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="error" class="alert alert-danger mx-auto col-11 col-sm-4 col-lg-12"><span><?php echo e($message); ?></span></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-12 col-md-6 col-lg-4">
                <h4><label for="">Descripcion</label></h4>
                <textarea class="form-control" name="description" id="" cols="30" rows="5"><?php echo e($service->description); ?></textarea>
                <small id="passwordHelpBlock" class="form-text text-muted"><b>Descripcion del servicio</b></small>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="error" class="alert alert-danger mx-auto col-11 col-sm-4 col-lg-12"><span><?php echo e($message); ?></span></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-12 col-md-6 col-lg-8">
                <h4>Especificaciones</h4>
                <div class="row">
                    <?php $__currentLoopData = $specs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6">
                        <input type="checkbox" name="specs[]" value="<?php echo e($spec->id); ?>" 
                            <?php $__currentLoopData = $service->specs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($data->id == $spec->id): ?>
                                        checked
                                    <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>> <?php echo e(ucfirst($spec->description)); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div id="buttons" class="text-center col-12">
            <button class="mx-2 btn btn-outline-dark" type="submit">Agregar</button>
            <a href="<?php echo e(route('service.index')); ?>"><button class="btn btn-outline-dark" type="button">Cancelar</button></a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DooM\Desktop\proyectos\marketing-ideal\resources\views/admin/service/edit.blade.php ENDPATH**/ ?>