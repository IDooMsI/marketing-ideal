
<?php $__env->startSection('content'); ?>
<div id="" class="col-12">
    <div class="mx-auto text-center col-12">
        <h2>Subcategorias</h2>
        <a href="<?php echo e(route('admin')); ?>" style="text-decoration: none; color:black"><i class="fas fa-arrow-circle-left"></i> Volver</a>
    </div>
    <div class="row justify-content-center mx-auto mb-3 col-12 col-md-8 col-lg-6 col-xl-4">
        <div class="my-3 col-6 col-md-4">
            <a href="<?php echo e(route('subcategory.create')); ?>"><button class="btn btn-outline-dark w-100">Nueva</button></a>
        </div>
    </div>
    <div class="my-2 col-12 text-center">
        <?php if(Session::has('notice')): ?>
        <h3 class="my-auto text-success"><strong><?php echo e(Session::get('notice')); ?></strong></h3>
        <?php endif; ?>
    </div>
</div>
<div class="table" style="overflow-x:auto;">
    <table class="mx-auto">
        <thead>
            <tr class="text-center">
                <th scope="col">#</th>
                <th scope="col">Nombre</th>
                <th scope="col">Opciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($data->id); ?></th>
                <th><?php echo e($data->name); ?></th>
                <th>
                    <a href="<?php echo e(route('subcategory.edit',['subcategory'=>$data])); ?>">editar</a>
                    ||
                    <a href="<?php echo e(route('subcategory.delete',['id'=>$data])); ?>">eliminar</a>
                </th>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DooM\Desktop\proyectos\marketing-ideal\resources\views/admin/subcategory/index.blade.php ENDPATH**/ ?>