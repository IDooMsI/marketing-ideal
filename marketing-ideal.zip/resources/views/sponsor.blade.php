@extends('layouts.app')
@section('content')
<div class="container text-center">
    <h1>Estamos trabajando para que muy pronto puedas disfrutar de esta seccion</h1>
    <img src="{{ asset('storage/publicidad.png') }}" class="w-100" alt="">
</div>
@endsection