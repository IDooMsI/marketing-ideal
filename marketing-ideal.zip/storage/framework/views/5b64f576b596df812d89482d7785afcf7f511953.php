
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="text-center mb-3">
            <h1 id="title-job">CLIENTES SATISFECHOS</h1>
        </div>
        <div class="border-top border-warning mt-3"></div>
        <div class="border-top border-warning w-75 mx-auto my-2"></div>
        <div class="border-top border-warning w-50 mx-auto mb-3"></div>
        <section class="row">
            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-md-6 col-lg-4 text-center h-100">
                <div class="border boder-dark p-2">
                    <h3><?php echo e($job->title); ?></h3>
                    <?php if(strpos($job->image,'mp4') !== false): ?>
                    <video class="w-100" id="video-job" controls poster="">
                        <source src="<?php echo e(asset('storage/'.$job->image)); ?>" type="video/mp4">
                    </video>
                    <?php else: ?>
                    <img class="w-100" src="<?php echo e(asset('storage/'.$job->image)); ?>" alt="">
                    <?php endif; ?>
                    <p><?php echo e($job->description); ?></p>
                    <a href="<?php echo e($job->link); ?>"><?php echo e($job->link); ?></a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DooM\Desktop\proyectos\marketing-ideal\resources\views/job.blade.php ENDPATH**/ ?>