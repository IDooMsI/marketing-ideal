
<?php $__env->startSection('content'); ?>
<div class="container">
    <div id="div-admin-buttons" class="row mt-3 justify-content-center">
        <div class="col-2">
            <a href="<?php echo e(route('service.index')); ?>"><button class="btn btn-block btn-outline-dark">Servicios</button></a>
        </div>
        <div class="col-2">
            <a href="<?php echo e(route('spec.index')); ?>"><button class="btn btn-block btn-outline-dark">Especificaciones</button></a>
        </div>
        <div class="col-2">
            <a href="<?php echo e(route('job.index')); ?>"><button class="btn btn-block btn-outline-dark">Trabajos</button></a>
        </div>
         <div class="col-2">
            <a href="<?php echo e(route('subcategory.index')); ?>"><button class="btn btn-block btn-outline-dark">Subcategorias</button></a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DooM\Desktop\proyectos\marketing-ideal\resources\views/admin/index.blade.php ENDPATH**/ ?>