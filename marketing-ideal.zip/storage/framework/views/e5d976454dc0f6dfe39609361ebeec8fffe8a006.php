
<?php $__env->startSection('content'); ?>
<div class="container text-center">
    <h1>Estamos trabajando para que muy pronto puedas disfrutar de esta seccion</h1>
    <img src="<?php echo e(asset('storage/publicidad.png')); ?>" class="w-100" alt="">
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DooM\Desktop\proyectos\marketing-ideal\resources\views/sponsor.blade.php ENDPATH**/ ?>