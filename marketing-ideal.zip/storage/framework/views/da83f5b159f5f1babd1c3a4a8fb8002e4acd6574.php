
<?php $__env->startSection('content'); ?>
<div class="container">
    <form action="">
        <?php echo csrf_field(); ?>
        <div class="form-group col-2 tex-center mx-auto">
            <label for="">Nombre</label>
            <input type="text" class="form-control">

            <label for="">Apellido</label>
            <input type="text" class="form-control">
            
            <label for="">Email</label>
            <input type="text" class="form-control" placeholder="example@email.com">
            
            <label for="">Consulta</label>
            <textarea class="form-control" name="" id="" cols="5" rows="5"></textarea>
            
            <button type="button" class="btn btn-primary">Enviar</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DooM\Desktop\proyectos\marketing-ideal\resources\views/contact.blade.php ENDPATH**/ ?>